using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MidtermTodos.Pages.Todos
{
    public class TodoDeleteSuccessModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
