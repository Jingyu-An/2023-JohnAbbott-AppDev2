using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MidtermTodos.Pages.Todos
{
    public class TodoUpdateSuccessModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
