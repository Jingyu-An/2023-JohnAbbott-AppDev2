using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MidtermTodos.Pages.Todos
{
    public class TodoAddSuccessModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
